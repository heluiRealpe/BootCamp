let greeting = require('./codenotch-node/greeting');

greeting.greeting('Héctor');