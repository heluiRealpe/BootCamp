function greeting(name) {
    console.log(`Hola ${name}! cómo estas?`)
}

module.exports = { greeting }